import React from 'react';
// FIX: Import Variants type from framer-motion to correctly type animation variants.
import { motion, Variants } from 'framer-motion';
import AnimatedShapes from './AnimatedShapes';

interface Social {
  name: string;
  url: string;
}

interface HeaderProps {
  name: string;
  title: string;
  socials: Social[];
  avatarUrl: string;
}

const headerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants: Variants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      duration: 0.5,
      ease: 'easeOut',
    },
  },
};

const Header: React.FC<HeaderProps> = ({ name, title, socials, avatarUrl }) => {
  return (
    <header className="py-12 text-center relative z-10 overflow-hidden">
      <AnimatedShapes />
      <motion.div variants={headerVariants} initial="hidden" animate="visible">
        <motion.div variants={itemVariants} className="mb-6">
          <img
            src={avatarUrl}
            alt={name}
            className="rounded-full w-40 h-40 md:w-48 md:h-48 object-cover mx-auto border-4 border-[var(--color-border)] shadow-lg hero-avatar-glow"
          />
        </motion.div>
        <motion.h1
          variants={itemVariants}
          className="text-5xl md:text-6xl font-black text-transparent bg-clip-text"
          style={{ backgroundImage: 'linear-gradient(to right, var(--color-accent-400), var(--color-accent-600))' }}
        >
          {name}
        </motion.h1>
        <motion.p variants={itemVariants} className="mt-4 text-xl text-[var(--color-text-muted)]">
          {title}
        </motion.p>
        <motion.div variants={itemVariants} className="mt-6 flex justify-center space-x-6">
          {socials.map((social) => (
            <a
              key={social.name}
              href={social.url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[var(--color-text-muted)] hover:text-[var(--color-accent-400)] transition-colors duration-300 text-lg"
              aria-label={social.name}
            >
              {social.name}
            </a>
          ))}
        </motion.div>
      </motion.div>
    </header>
  );
};

export default Header;