import React from 'react';

interface ThemeSwitcherProps {
  currentTheme: string;
  setTheme: (theme: string) => void;
}

const themes = [
  { name: 'blue', style: { background: '#58a6ff' } },
  { name: 'green', style: { background: '#39FF14' } },
  { name: 'red', style: { background: '#ff2525' } },
  { name: 'rgb', style: { background: 'linear-gradient(45deg, #ff5050, #ffc800, #96005c, #1f005c)' } },
];

const ThemeSwitcher: React.FC<ThemeSwitcherProps> = ({ currentTheme, setTheme }) => {
  return (
    <div className="absolute top-4 right-4 bg-[var(--color-card)] p-2 rounded-full shadow-lg border border-[var(--color-border)] z-50">
      <div className="flex space-x-2">
        {themes.map((theme) => (
          <button
            key={theme.name}
            onClick={() => setTheme(theme.name)}
            className={`w-6 h-6 rounded-full transition-transform duration-200 transform hover:scale-110 focus:outline-none ${currentTheme === theme.name ? 'ring-2 ring-offset-2 ring-offset-[var(--color-bg)] ring-white' : ''}`}
            style={theme.style}
            aria-label={`Switch to ${theme.name} theme`}
          />
        ))}
      </div>
    </div>
  );
};

export default ThemeSwitcher;