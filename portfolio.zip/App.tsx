


import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import Header from './components/Header';
import About from './components/About';
import Experience from './components/Experience';
import Projects from './components/Projects';
import Education from './components/Education';
import Skills from './components/Skills';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ThemeSwitcher from './components/ThemeSwitcher';
import Modal from './components/Modal';
import Navbar from './components/Navbar';

// Simple CSV parser that handles quoted fields
const parseCSV = (text: string): Record<string, string>[] => {
  const lines = text.trim().split('\n');
  if (lines.length < 2) return [];
  const header = lines[0].split(',').map(h => h.trim());
  return lines.slice(1).map(line => {
    const values = line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
    return header.reduce((obj, key, index) => {
      let value = values[index] ? values[index].trim() : '';
      if (value.startsWith('"') && value.endsWith('"')) {
        value = value.slice(1, -1);
      }
      obj[key] = value;
      return obj;
    }, {} as Record<string, string>);
  });
};

const App: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [theme, setTheme] = useState('blue');
  const [selectedProject, setSelectedProject] = useState<any | null>(null);

  // Parallax effect on scroll
  useEffect(() => {
    const handleScroll = () => {
        const scrollY = window.scrollY;
        document.body.style.backgroundPosition = `0px ${-scrollY * 0.2}px`;
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  useEffect(() => {
    const fetchAllData = async () => {
      try {
        const dataFiles = [
          'config', 'socials', 'about', 'experience', 
          'projects', 'real_world_projects', 'education', 'skills', 'contact'
        ];
        
        const responses = await Promise.all(
          dataFiles.map(file => fetch(`/data/${file}.csv`).then(res => res.text()))
        );

        const parsedData = responses.reduce((acc, text, index) => {
          const key = dataFiles[index].replace(/_/g, '');
          const parsed = parseCSV(text);
          if (key === 'config') {
            acc[key] = parsed.reduce((obj: Record<string, string>, item: Record<string, string>) => {
              obj[item.key] = item.value;
              return obj;
            }, {});
          } else if (key === 'contact' && parsed.length > 0) {
            acc[key] = parsed[0];
          }
           else {
            acc[key] = parsed;
          }
          return acc;
        }, {} as Record<string, any>);
        
        setData(parsedData);
      } catch (e) {
        setError('Failed to load portfolio data. Please try refreshing the page.');
        console.error(e);
      } finally {
        setLoading(false);
      }
    };

    fetchAllData();
  }, []);
  
  const handleViewProject = (project: any) => setSelectedProject(project);
  const handleCloseModal = () => setSelectedProject(null);


  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-xl bg-[var(--color-bg)] text-[var(--color-text-base)]">Loading Portfolio...</div>;
  }
  
  if (error) {
    return <div className="min-h-screen flex items-center justify-center text-xl text-red-400 bg-[var(--color-bg)]">{error}</div>;
  }

  const techSkills = data.skills.filter((s: any) => s.type === 'tech');
  const softSkills = data.skills.filter((s: any) => s.type === 'soft');

  return (
    <div className="min-h-screen bg-[var(--color-bg)]">
      <Navbar />
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-5xl">
        <ThemeSwitcher currentTheme={theme} setTheme={setTheme} />
        <Header 
          name={data.config.name} 
          title={data.config.title} 
          socials={data.socials}
          avatarUrl={data.config.avatar_url}
        />
        <main className="py-12">
          <div id="about" className="scroll-mt-16">
            <About 
              bio={data.about.map((p: any) => p.paragraph)} 
            />
          </div>
          <div id="projects" className="scroll-mt-16">
            <Projects title="Real World Projects" emoji="💼" projects={data.realworldprojects} onViewDetails={handleViewProject} />
            <Projects title="Personal Projects" emoji="🚀" projects={data.projects} onViewDetails={handleViewProject}/>
          </div>
          <div id="experience" className="scroll-mt-16">
            <Experience experience={data.experience} />
          </div>
          <div id="education" className="scroll-mt-16">
            <Education education={data.education} />
          </div>
          <div id="skills" className="scroll-mt-16">
            <Skills skills={techSkills} softSkills={softSkills} />
          </div>
          <div id="contact" className="scroll-mt-16">
            <Contact 
              heading={data.contact.heading} 
              message={data.contact.message} 
              email={data.contact.email}
              phone={data.contact.phone} 
            />
          </div>
        </main>
        <Footer name={data.config.name} />
      </div>
      <AnimatePresence>
        {selectedProject && <Modal project={selectedProject} onClose={handleCloseModal} />}
      </AnimatePresence>
    </div>
  );
};

export default App;